/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.editorConfig=function(a){a.PreserveSessionOnFileBrowser=!0,a.language="ru",a.height="400px",a.width="600px",a.toolbar="Easy",a.format_tags="h3",a.toolbar_Easy=[["PageBreak","-"],["Cut","Copy","Paste","PasteText","PasteFromWord"],["Undo","Redo","-"],["Format","Bold","Italic","Underline","Strike"],["NumberedList","BulletedList","-","Outdent","Indent","Blockquote"],["JustifyLeft","JustifyCenter","JustifyRight","JustifyBlock"],["Link","Unlink","Anchor"],["Image","Embed","Attachment","Table","HorizontalRule","Source"]]}